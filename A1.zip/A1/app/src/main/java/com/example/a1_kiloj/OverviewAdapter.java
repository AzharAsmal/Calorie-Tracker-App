package com.example.a1_kiloj;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import static android.support.v4.content.ContextCompat.startActivity;

public class OverviewAdapter extends RecyclerView.Adapter<OverviewAdapter.OverviewHolder> {
    private ArrayList<Entry> entryList;
    private OnOverviewListener onOverviewListener;
    private static final String TAG = "DiaryOverview";

    public OverviewAdapter(ArrayList<Entry> entryList, OnOverviewListener onOverviewListener){
        this.entryList = entryList;
        this.onOverviewListener = onOverviewListener;
    }

    public static class OverviewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView date;
        public TextView totalNki;
        OnOverviewListener overviewListener;

        public OverviewHolder(View itemView, OnOverviewListener overviewListener) {
            super(itemView);
            date = itemView.findViewById(R.id.date);
            totalNki = itemView.findViewById(R.id.netValue);
            this.overviewListener = overviewListener;
        }

        @Override
        public void onClick(View view) {
            overviewListener.onOverviewClick(getAdapterPosition());
        }
    }

    @Override
    public OverviewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.entry_overview, parent, false);
        OverviewHolder overview = new OverviewHolder(v, onOverviewListener);
        return overview;
    }

    @Override
    public void onBindViewHolder(OverviewHolder holder, final int position) {
        Entry currentItem = entryList.get(position);

        holder.date.setText(currentItem.getDate());
        holder.totalNki.setText(currentItem.getTotal());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "onOverview2: click registered");
                Intent intent = new Intent(view.getContext(), Diary.class);
                intent.putExtra("entryPos", position);
                view.getContext().startActivity(intent);
            }
        });
    }

    public interface OnOverviewListener{
        void onOverviewClick(int pos);
    }

    @Override
    public int getItemCount() {
        return entryList.size();
    }
}

