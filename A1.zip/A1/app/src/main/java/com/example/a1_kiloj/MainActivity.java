package com.example.a1_kiloj;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.w3c.dom.Text;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements OverviewAdapter.OnOverviewListener {

    private static final String TAG = "DiaryOverview";
    ArrayList<Entry> entryList;
    public static final String SHARED_PREF = "sharedPref";
    public static final String ENTRIES = "entries";

    public static RecyclerView diaryView;
    private OverviewAdapter overAdapt;
    private RecyclerView.LayoutManager diaryManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        loadEntries();
        buildRecyclerView();
        TextView avgNki = (TextView)findViewById(R.id.dayAvg);
        avgNki.setText("Daily Average Net KiloJoules: "+ avgNKI());

        Button fab = findViewById(R.id.calcLaunch);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Calculator.class));
            }
        });
        Button diaryLaunch = findViewById(R.id.entry_page);
        diaryLaunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Diary.class));
            }
        });

    }

    /*private void processEntries(String s){
        JSONArray entries = null;

        try{
            entries = new JSONArray(s);
        }
        catch (JSONException e) {
            e.printStackTrace();
        }
        for (int i = 0; i<entries.length(); i++) {
            try {
                Diary.addEntry((String) entries.get(i));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
    */
    @Override
    protected void onSaveInstanceState (Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onStart() {
        // This happens when the Activity comes into view
        super.onStart();

        //updateEntryCount();
    }

    @Override
    public void finish() {
        //saveEntries();

        super.finish();
    }

    /*private void saveEntries() {
        JSONArray entryList = new JSONArray(Diary.getDiaryEntries());
        diaryEditor.putString("entries", entryList.toString());
        diaryEditor.apply();
    }*/

    private void loadEntries() {
        SharedPreferences sharedPref = getSharedPreferences(SHARED_PREF, MODE_PRIVATE);
        Gson gson = new Gson();
        String jStore = sharedPref.getString(ENTRIES, null);
        Type type = new TypeToken<ArrayList<Entry>>() {}.getType();
        entryList = gson.fromJson(jStore, type);

        if (entryList == null) {
            entryList = new ArrayList<>();
        }
    }

    private void buildRecyclerView() {
        diaryView = findViewById(R.id.diaryView);
        diaryView.setHasFixedSize(true);
        diaryManager = new LinearLayoutManager(this);
        overAdapt = new OverviewAdapter(entryList, this);

        diaryView.setLayoutManager(diaryManager);
        diaryView.setAdapter(overAdapt);
    }

    //method to calculate average daily NKI
    //!!might not work as intended
    public float avgNKI(){
        Entry floaty;
        float sum = 0;
        int c;
        for(c = 0; c<entryList.size();c++){
            floaty = entryList.get(c);
            sum += Float.parseFloat(floaty.getTotal());
        }

        float average = sum/c;
        return average;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        else if(id == R.id.clearData){
            entryList = new ArrayList<>();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onOverviewClick(int pos) {
        Log.d(TAG, "onOverview: click registered");
        Intent intent = new Intent(this, Diary.class);
        intent.putExtra("entryPos", pos);
        this.startActivity(intent);
    }

}
