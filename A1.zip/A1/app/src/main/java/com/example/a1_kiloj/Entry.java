package com.example.a1_kiloj;

import java.util.ArrayList;

public class Entry {
    private ArrayList<String> foodItems;
    private ArrayList<String> exItems;
    private String date;
    private String total;
    private String intake;
    private String burn;

    public Entry(String date, String total, String intake, String burn, ArrayList<String> foodItems, ArrayList<String> exItems){
        this.date = date;
        this.total = total;
        this.burn = burn;
        this.intake = intake;
        this.foodItems = foodItems;
        this.exItems = exItems;
    }

    public String getDate() {
        return date;
    }

    public String getTotal() {
        try{
            Float.parseFloat(total);
        }
        catch (NumberFormatException e){
            total = "0";
        }
        return total;
    }

    public String getIntake() {
        return intake;
    }

    public String getBurn() {
        return burn;
    }

    public ArrayList<String> getFoodItems() {
        return foodItems;
    }

    public ArrayList<String> getExItems() {
        return exItems;
    }
}
