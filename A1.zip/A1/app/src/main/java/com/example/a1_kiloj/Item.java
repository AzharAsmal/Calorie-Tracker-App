package com.example.a1_kiloj;

public class Item {
}
