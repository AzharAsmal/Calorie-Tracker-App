package com.example.a1_kiloj;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.SharedMemory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class Calculator extends AppCompatActivity {

    String date;
    float inCal, burnCal, totalCal;
    String totalCalorie;

    //new JSON implement
    ArrayList<Entry> entryList;
    ArrayList<String> food;
    ArrayList<String> ex;
    public static final String SHARED_PREF = "sharedPref";
    public static final String ENTRIES = "entries";
    //private EntryAdapter entryAdapter;



    /*public Calculator(Entry entry){
        TextView intake = findViewById(R.id.intakeText);
        TextView burn = findViewById(R.id.burnText);
        TextView total = findViewById(R.id.total);
        intake.setText(entry.getIntake());
        burn.setText(entry.getBurn());
        total.setText(entry.getTotal());
        startActivity(new Intent(getApplicationContext(), Calculator.class));
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);
        inCal = 0;
        burnCal = 0;
        totalCal = 0;

        loadEntries();
        Button save = findViewById(R.id.saveBtn);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(totalCal == 0 && inCal == 0 && burnCal == 0) {
                    throwToast(0);
                }
                else {
                    generateEntry();
                    saveEntry();
                }
            }
        });

        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat form = new SimpleDateFormat("dd-MM-yyyy");
        date = form.format(c);
        EditText dateText = findViewById(R.id.dateText);
        dateText.setText(date);
    }

    private void throwToast(int i) {
        if(i == 0) {
            Toast.makeText(this, getString(R.string.noValues), Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, getString(R.string.noInput), Toast.LENGTH_SHORT).show();
        }
    }

    private void loadEntries() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREF, MODE_PRIVATE);
        Gson gson = new Gson();
        String jStore = sharedPreferences.getString(ENTRIES, null);
        Type type = new TypeToken<ArrayList<Entry>>() {}.getType();
        entryList = gson.fromJson(jStore, type);

        if (entryList == null) {
            entryList = new ArrayList<>();
            food = new ArrayList<>();
            ex = new ArrayList<>();
        }
    }

    private void saveEntry() {
        SharedPreferences saveP = this.getSharedPreferences(SHARED_PREF, Activity.MODE_PRIVATE);
        SharedPreferences.Editor myEdit = saveP.edit();
        Gson gson = new Gson();
        String jStore = gson.toJson(entryList);
        myEdit.putString(ENTRIES, jStore);
        myEdit.apply();
        Toast.makeText(this, "Added Entry!", Toast.LENGTH_SHORT).show();
        clearAll();
        //MainActivity.diaryView.getAdapter().notifyDataSetChanged();
        startActivity(new Intent(getApplicationContext(), Diary.class));
    }

    private void clearAll() {
        TextView total = findViewById(R.id.total);
        TextView intake = findViewById(R.id.intakeText);
        TextView burn = findViewById(R.id.burnText);
        total.setText("");
        intake.setText("");
        burn.setText("");
    }

    private void generateEntry(){
        TextView intake = (TextView) findViewById(R.id.intakeText);
        TextView burn = (TextView) findViewById(R.id.burnText);
        TextView total = (TextView) findViewById(R.id.total);
        EditText dateText = findViewById(R.id.dateText);
        date = dateText.getText().toString();
        newEntry(date, total.getText().toString(),intake.getText().toString(),burn.getText().toString(), getFood(), getEx());
    }

    private ArrayList<String> getFood() {
        return food;
    }

    private ArrayList<String> getEx(){
        return ex;
    }

    private void newEntry(String date, String total, String intake, String burned, ArrayList<String> food, ArrayList<String> ex){
        entryList.add(new Entry(date, total, intake, burned, food, ex));
    }

    public void onStop(){
        //saveEntry();
        super.onStop();
    }

    public void addFood(View view) {
        Button f = (Button)view;
        String item = f.getText().toString();

        TextView intake = findViewById(R.id.intakeText);
        EditText input = findViewById(R.id.input);
        String in = input.getText().toString();

        if(in.equals("")) {
            throwToast(1);
        }
        else{
            inCal += Float.parseFloat(input.getText().toString());
            totalCal = inCal - burnCal;
            intake.setText(inCal + "");
            input.setText("");
            item = item + ": "+in+" kJ";
            food.add(item);
            updateTotal();
        }
    }

    public void addEx(View view){
        Button e = (Button)view;
        String item = e.getText().toString();

        TextView burnt = findViewById(R.id.burnText);
        EditText input = findViewById(R.id.input);
        String in = input.getText().toString();
        if(in.equals("")) {
            throwToast(1);
        }
        else{
            burnCal += Float.parseFloat(in);
            totalCal = inCal - burnCal;
            burnt.setText(burnCal + "");
            input.setText("");
            item = item + ": "+in+" kJ";
            ex.add(item);
            updateTotal();
        }
    }

    public void updateTotal(){
        TextView total = findViewById(R.id.total);

        total.setText(totalCal+"");
    }

}
