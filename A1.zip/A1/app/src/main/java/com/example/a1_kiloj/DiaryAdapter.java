package com.example.a1_kiloj;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearSmoothScroller;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;

import static android.R.layout.simple_list_item_2;

public class DiaryAdapter extends RecyclerView.Adapter<DiaryAdapter.DiaryViewHolder> {
    private ArrayList<Entry> entryList;

    Context context;





    public DiaryAdapter(ArrayList<Entry> entryList, Context context){
        this.entryList = entryList;
        this.context = context;
    }

    public class DiaryViewHolder extends RecyclerView.ViewHolder {
        //ImageView edit;
        TextView date;
        TextView total;
        TextView intake;
        TextView burn;
        ListView food;
        ListView ex;
        //ArrayAdapter adapter;
        ArrayList<String> fList;
        ArrayList<String> exList;




        public DiaryViewHolder(View view) {
            super(view);
            //edit = view.findViewById(R.id.edit_image);
            fList = new ArrayList<String>();
            exList = new ArrayList<String>();
            date = view.findViewById(R.id.date);
            total = view.findViewById(R.id.total);
            intake = view.findViewById(R.id.intake);
            burn = view.findViewById(R.id.burn);
            food = view.findViewById(R.id.foodItems);
            ex = view.findViewById(R.id.exItems);
            ArrayAdapter adapter1;
            ArrayAdapter adapter2;
            adapter1= new ArrayAdapter<String>(context, simple_list_item_2, fList );
            adapter2= new ArrayAdapter<String>(context, simple_list_item_2, exList );
            food.setAdapter(adapter1);
            ex.setAdapter(adapter2);


        }
    }


    @Override
    public DiaryViewHolder onCreateViewHolder(ViewGroup parent, int v){
        View diaryView = LayoutInflater.from(parent.getContext()).inflate(R.layout.diary_card, parent, false);
        DiaryViewHolder holder = new DiaryViewHolder(diaryView);
        return holder;
    }

    @Override
    public void onBindViewHolder(DiaryViewHolder holder, final int i) {
        holder.date.setText(entryList.get(i).getDate());
        holder.total.setText(entryList.get(i).getTotal());
        holder.intake.setText(entryList.get(i).getIntake());
        holder.burn.setText(entryList.get(i).getBurn());
        holder.fList = entryList.get(i).getFoodItems();
        holder.exList = entryList.get(i).getExItems();


    }

    @Override
    public int getItemCount() {
        return entryList.size();
    }
}
