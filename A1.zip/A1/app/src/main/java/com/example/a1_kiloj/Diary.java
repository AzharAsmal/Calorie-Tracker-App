package com.example.a1_kiloj;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.LinearSmoothScroller;
import android.support.v7.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class Diary extends AppCompatActivity {
    Calculator calc;

    private RecyclerView diaryView;
    private DiaryAdapter adapter;
    private ArrayList<Entry> entryList;
    public static final String SHARED_PREF = "sharedPref";
    public static final String ENTRIES = "entries";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary);

        diaryView = (RecyclerView) findViewById(R.id.diaryCards);
        diaryView.setLayoutManager(new LinearLayoutManager(this));
        Bundle extras = getIntent().getExtras();
        loadEntries();
        adapter = new DiaryAdapter(entryList,this);
        diaryView.setAdapter(adapter);
        if (extras != null){
            int pos = extras.getInt("entryPos");
            try {
                diaryView.getLayoutManager().scrollToPosition(pos);
            }
            catch (NullPointerException e){
                e.printStackTrace();
            }
        }

    }


    private void loadEntries() {
        SharedPreferences sharedPref = getSharedPreferences(SHARED_PREF, MODE_PRIVATE);
        Gson gson = new Gson();
        String jStore = sharedPref.getString(ENTRIES, null);
        Type type = new TypeToken<ArrayList<Entry>>() {}.getType();
        entryList = gson.fromJson(jStore, type);
        diaryView.scrollToPosition(entryList.size()-1);

        if (entryList == null) {
            entryList = new ArrayList<>();
        }
    }
}